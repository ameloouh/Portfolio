import { formatTime } from "./detailPageHilfsfunktionen.js";
import { beitrag } from "./detailPage.js";

/***************************************************Tags auswählen & abspeichern******************************************************************/

let tags = document.querySelectorAll(".tag");
let tagList = [].sort(); //Array mit allen Tags, die ausgewählt wurden

tags.forEach((tag) => {
  tag.addEventListener("click", function () {
    tag.classList.toggle("clicked");
    let tagText = tag.textContent;
    //nur wenn der Tag aktiv ist, wird er in die Datenbank/Liste geschrieben/gespeichert
    if (tag.classList.contains("clicked")) {
      tagList.push(tagText);
    } else {
      tagList.splice(tagList.indexOf(tagText), 1);
      console.log(tagList);
    }
  });
});

/************************Hinzufügen von Text & Tags bei Klick auf das Plus-Button + Abspeichern in der Datenbank***********************************/

const addButton = document.getElementById("add");

addButton.addEventListener("click", function () {
  let value = addButton.previousElementSibling.value, //Text aus dem Kommentar-Textfeld
    comment = document.querySelector(".comment").cloneNode(true); //Klonen des Kommentar-Template-Elements

  /*Kommentar-Template: Zeitstempel, Kommentar, Tags:

   *1. Zeitstempel:*/
  let timeElement = comment.children[0], //Zeit-Element im Kommentar-Template
    audio = document.querySelector("audio"), //Audio-Element
    time = audio.currentTime; //Aktuelle Zeit im Audio-Element (in Sekunden)
  timeElement.textContent = formatTime(time); //Zeit-Element im Kommentar-Template wird mit der aktuellen Zeit im Audio-Element überschrieben

  /*2. Kommentar:*/
  let commentText = comment.children[1]; //Text-Element im Kommentar-Template
  commentText.textContent = value; //Text-Element im Kommentar-Template wird mit dem Text aus dem Kommentar-Textfeld überschrieben

  /*3. Tags:*/
  let tagBox = comment.children[2]; //Tag-Element im Kommentar-Template
  tagBox.textContent = tagList.join(" "); //Tag-Element im Kommentar-Template wird mit den ausgewählten Tags überschrieben

  //Beiträge zur Audio sollen nur erstellt werden können, wenn ein Text verfasst oder Tags ausgewählt wurden:
  if (value != "" || tagList.length != 0) {
    commentBox.appendChild(comment);
  }

  //Abspeichern der Audio-Beiträge in der Datenbank:
  myDatabase.getResultSet(`
  INSERT INTO Kommentare (Timestamp, Kommentar, Tags, Beitrags_ID)
  VALUES ('${timeElement.textContent}', '${value}', '${tagList}', '${beitrag.id}')
  `);

  //Zurücksetzen des Kommentar-Textfelds und der ausgewählten Tags:
  const input = document.getElementById("Comment");
  input.value = "";

  tags.forEach((tag) => tag.classList.remove("clicked"));
  tagList = [];
});

/************************Beim Klicken auf den Zeitstempel soll der Audio-Player zur entsprechenden Zeit springen***********************************/

document.body.addEventListener("click", function (event) {
  if (event.target.classList.contains("time")) {
    let audio = document.querySelector("audio"); //Audio-Element
    let time = event.target.textContent; //Zeitstempel
    let audioPfad = "./data/media/" + beitrag.id + ".mp3#t=" + time; //Pfad zum Audio-File mit Zeitstempel
    audio.src = audioPfad; //Audio-Player springt zur entsprechenden Zeit
    audio.play(); //Audio-Player spielt ab
  }
});
