//prettier-ignore
import {fuzzySearch, exactSearch} from "./searchFunctions.js";
import beitraege from "./searchPageResults.js";

/**************************************************Searchbar*******************************************************************/

const searchInput = document.querySelector(".searchTerm");

searchInput.addEventListener("input", (e) => {
  let value = e.target.value.trim().toLowerCase();
  fuzzySearch(value);
});

//die Beitragskarten werden entsprechend der Eingabe in die Suchleiste gefiltert;

/**********************************************Open-DropDown*******************************************************************/

const buttons = document.querySelectorAll(".menu");

buttons.forEach((button) => {
  button.addEventListener("click", () => {
    button.nextElementSibling.classList.toggle("show");
  });
});

//Beim Click auf ein Dropdown Menu Button öffnet sich das entsprechende Dropdown Menu

/**********************************************DropDown-Searchbar*******************************************************************/

const dropInputs = document.querySelectorAll(".myInput");

dropInputs.forEach((input) => {
  input.addEventListener("keyup", () => {
    let value = input.value.toLowerCase();
    let options = input.nextElementSibling.children;

    for (var i = 0; i < options.length; i++) {
      const optionText = options[i].textContent;

      if (optionText.toLowerCase().indexOf(value) > -1) {
        options[i].style.display = "";
      } else {
        options[i].style.display = "none";
      }
    }
  });
});

//Bei Eingabe eines Suchwertes in die Suchleiste eines Dropdown Menus, werden die Optionen gefiltert

/**********************************************DropDown-Filter*******************************************************************/

const dropDownContent = document.querySelectorAll(".options");

dropDownContent.forEach((option) => {
  option.addEventListener("click", (e) => {
    let value = e.target.textContent.toLowerCase().trim();
    exactSearch(value);
    //DropDown wieder schließen nach Auswahl
    e.target.parentElement.parentElement.classList.toggle("show");
  });
});

//beim Click auf eines der Dropdown-Button-Optionen, werden die Beitragskarten entsprechend der Auswahl gefiltert

/**********************************************Reset-Button*******************************************************************/

const resetButton = document.querySelector(".reset");

function reset() {
  //alle Beiträge wieder anzeigen
  beitraege.forEach((beitrag) => {
    beitrag.element.classList.remove("hide");
  });
  searchInput.value = ""; //Suchleiste leeren
}

resetButton.addEventListener("click", reset);

//beim Click auf den Reset-Button, werden alle Beiträge wieder angezeigt und die Suchleiste geleert

/**********************************************Weiterleitung*******************************************************************/

beitraege.forEach((beitrag) => {
  beitrag.element.addEventListener("click", () => {
    localStorage.setItem("beitrag", JSON.stringify(beitrag.data));
    window.location.href = "detailPage.html?id=" + beitrag.data.id;
  });
});

/*
 * beim Click auf einen Beitrag, werden die Daten des angeklickten Beitrages in den LocalStorage geschrieben &
 * die Seite detail.html wird mit einer individuellen Endung (die der Beitrags-ID entspricht) aufgerufen
 */
