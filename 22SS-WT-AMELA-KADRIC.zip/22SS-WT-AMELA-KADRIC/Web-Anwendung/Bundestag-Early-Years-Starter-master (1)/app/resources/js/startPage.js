import myDatabase from "./databaseconnector.js";

/**
 * Funktion, die die Statisiken auf der Startseite aktualisiert
 * @param elementID - ID des HTML-Elements, das aktualisiert werden soll
 * @param newText - Statistik, die in das HTML-Element geschrieben werden soll
 */

function updateHTML(elementID, newText) {
  let element, elementText;

  element = document.getElementById(elementID);
  elementText = element.innerHTML;
  element.innerHTML = newText;
}

/**
 * Funktion, die die Jahresangaben auf der Startseite aktualisiert
 * @param elementID - ID des HTML-Elements, das aktualisiert werden soll
 * @param newDate - Jahresangabe, die in das HTML-Element geschrieben werden soll
 */

function updateDates(elementID, newDate) {
  let element = document.getElementById(elementID);
  element.innerHTML = newDate.split("-")[0];
}

/*Statisken aus der Datenbank*/
const stats = await myDatabase.getStats();

updateHTML("beitrag", stats.numSpeeches);
updateHTML("redner", stats.numSpeakers);
updateHTML("parteien", stats.numParties);
updateDates("minDate", stats.minDate);
updateDates("maxDate", stats.maxDate);
