/**
 * Hilfsfunktion, um die Sekunden in Minuten und Sekunden umzurechnen & ins richtige Format zu bringen
 * @param seconds - Anzahl der Sekunden
 **/

function formatTime(seconds) {
  let minutes = Math.floor(seconds / 60);
  minutes = minutes >= 10 ? minutes : "0" + minutes;
  seconds = Math.floor(seconds % 60);
  seconds = seconds >= 10 ? seconds : "0" + seconds;
  return minutes + ":" + seconds;
}

export { formatTime };
