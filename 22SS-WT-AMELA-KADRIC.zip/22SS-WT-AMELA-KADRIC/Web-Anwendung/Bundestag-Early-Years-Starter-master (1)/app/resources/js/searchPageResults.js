import myDatabase from "./databaseConnector.js";

/*
 * Hier werden alle Informationen zu den Beiträgen aus der Datenbank in Karten eingespeist, die
 * dann auf der Seite "suche.html" zu sehen sind
 */

const searchResultContainer = document.querySelector(
    "#search-results-container"
  ),
  searchResultTemplate = document.querySelector("#search-results-template");

let beitraege = []; //Array, um die später erstellten Beitrags-Objekte zu speichern*
const joinedTables = await myDatabase.joinAllTables(); //siehe databaseconnector.js
/*Unterschied zu joinedTables im Grunde nur, dass der Sprecher wieder zusammengesetzt wurde & die keys eine prägnantere, englische Bezeichnung erhalten haben*/

/*Zuordnung von einem Beitrag zu einem Div-Element; Clonen des Templates aus "suche.html"; */
for (var i = 0; i < joinedTables.length; i++) {
  let beitrag = {
    element: searchResultTemplate.content.cloneNode(true).children[0],
    data: joinedTables[i],
  };

  /*Zusammenführung von HTML-Elementen und Daten aus der Datenbank:
   *
   *1.Entsprechende HTML-Elemente werden aus dem Template ausgelesen*/
  const sessionElement = beitrag.element.querySelector("#data-1"),
    topicElement = beitrag.element.querySelector("#data-2"),
    dateElement = beitrag.element.querySelector("#data-3"),
    speakerElement = beitrag.element.querySelector("#data-4"),
    partyElement = beitrag.element.querySelector("#data-5");
  /*2.Daten werden aus der Datenbank bzw. aus dem joinedTables-Array ausgelesen */
  let session = beitrag.data.Sitzungs_Nr,
    topic = beitrag.data.Titel,
    date = beitrag.data.Datum,
    speaker =
      beitrag.data.AkadGrad +
      " " +
      beitrag.data.Vorname +
      " " +
      beitrag.data.Nachname,
    party = beitrag.data.Fraktion,
    imgTxt = beitrag.data.Bildunterschrift,
    id = beitrag.data.Beitrags_ID,
    top = beitrag.data.TOP;

  /*3. Die ausgelesenen Daten werden in die HTML-Elemente eingefügt */
  sessionElement.textContent = session;
  topicElement.textContent = topic;
  dateElement.textContent = date;
  speakerElement.textContent = speaker;
  partyElement.textContent = party;

  /*4. Der Suchergebnisse-Container wird mit den einzelnen Beitrags-Elementen befüllt*/
  searchResultContainer.appendChild(beitrag.element);

  /*5. Die Daten werden in einem neuen Array "beitraege" gespeichert, siehe oben*/
  beitraege.push({
    data: {
      id: id,
      session: session,
      topic: topic,
      date: date,
      speaker: speaker,
      party: party,
      imgTxt: imgTxt,
      top: top,
    },
    element: beitrag.element,
  });
}

export default beitraege;
