import myDatabase from "./databaseConnector.js";

/*
 * Hier werden die zunächst leeren Dropdown-Menu-Elemente mit den einzigartigen Auswahloptionen
 * aus der Datenbank befüllt; wie die Werte generiert werden sieht man in "databaseConnector.js"
 */

//Werte für die Dropdown-Menüs aus der Datenbank holen
const distinctValues = await myDatabase.getDistinctValues();

/**
 * Funktion, um die Dropdown-Menus mit der Auswahl zu befüllen
 * @param selectionID - ID des Dropdown-HTML-Elements, das befüllt werden soll
 * @param queryResult - Ergebnis der Datenbankabfrage; siehe auch "databaseConnector.js"
 */

function createOptions(selectionID, queryResult) {
  const dropdownContent = document.querySelector(selectionID);

  for (var i = 0; i < queryResult.length; i++) {
    const opt = document.createElement("a");
    opt.classList.add("option");
    opt.textContent = Object.values(queryResult[i]).join(" ").trim();
    dropdownContent.appendChild(opt);
  }
}

//Befüllung der entsprechenden HTML-Elemente mit den Werten; siehe searchpageFunctions
createOptions("#speakerOptions", distinctValues.distinctSpeakers);
createOptions("#topicOptions", distinctValues.distinctTopics);
createOptions("#partyOptions", distinctValues.distinctParties);
createOptions("#sessionOptions", distinctValues.distinctSessions);
createOptions("#dateOptions", distinctValues.distinctDates);
createOptions("#topOptions", distinctValues.distinctTOP);
