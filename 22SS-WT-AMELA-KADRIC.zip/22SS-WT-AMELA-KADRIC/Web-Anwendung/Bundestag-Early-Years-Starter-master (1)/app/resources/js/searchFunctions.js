import beitraege from "./searchPageResults.js";

/**
 * Suchfunktion, die Eingaben mit allen Daten in der Datenbank (konkret dem Beitragsarray) abgleicht;
 * hierbei muss keine exakte Zeichenfolge als Suchkriterium zugrunde gelegt werden; es wird z.B. bereits
 * bei einzelnen Buchstaben nach passenden Beiträgen gesucht ("lo" = Louise Schroeder oder fraktionslos)
 * @param value - Sucheingabe
 */

function fuzzySearch(value) {
  beitraege.forEach((beitrag) => {
    const isVisible =
      beitrag.data.speaker.toLowerCase().includes(value) ||
      beitrag.data.topic.toLowerCase().includes(value) ||
      beitrag.data.date.includes(value) ||
      beitrag.data.session == value ||
      beitrag.data.top.toLowerCase().includes(value) ||
      beitrag.data.party.toLowerCase().includes(value);

    beitrag.element.classList.toggle("hide", !isVisible); //Ausblenden von unzutreffenden Beiträgen
  });
}

/**
 * Suchfunktion, bei der eine exakte Zeichenfolge als Suchkriterium zugrunde gelegt wird;
 * Anwendung: Dropdown Menu Optionen werden mit den Beitragskarten abgeglichen
 * @param value - Dropdown Menu Option, die angeglickt wurde
 */

function exactSearch(value) {
  beitraege.forEach((beitrag) => {
    const isVisible =
      beitrag.data.speaker.toLowerCase().trim() === value ||
      beitrag.data.topic.toLowerCase().trim() === value ||
      beitrag.data.date === value ||
      beitrag.data.session === parseInt(value) ||
      beitrag.data.top.trim() === value ||
      beitrag.data.party.toLowerCase().trim() === value;

    beitrag.element.classList.toggle("hide", !isVisible); //Ausblenden von unzutreffenden Beiträgen
  });
}

export { fuzzySearch, exactSearch };
