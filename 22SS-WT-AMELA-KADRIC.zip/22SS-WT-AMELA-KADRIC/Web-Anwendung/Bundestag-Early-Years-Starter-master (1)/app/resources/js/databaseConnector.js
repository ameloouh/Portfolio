import RemoteSQLiteDatabase from "./database/RemoteSQLiteDatabase.js";

// Klasse, um mit der Datenbank zu interagieren
class DatabaseConnector {
  constructor() {
    this.db = new RemoteSQLiteDatabase();
    this.db.connect();
  }

  // Funktion analog index.js
  async getResultSet(query) {
    let response, result;

    response = await this.db.runQuery(query);
    result = response.resultSet;
    return result;
  }

  //Hilfsfunktion; gibt den Wert des Attributs ATTR zurück; wird für die Statistiken benötigt
  async getAttrValue(query) {
    let response, result;

    response = await this.db.runQuery(query);
    result = await response.resultSet[0].ATTR;
    return result;
  }

  //Funktion, um Statistiken für die Startseite aus der Datenbank zu holen
  async getStats() {
    let numSpeeches, numSpeakers, numParties, minDate, maxDate;

    numSpeeches = await this.getAttrValue(
      "SELECT COUNT(*) AS ATTR FROM Redebeitrag"
    );
    numSpeakers = await this.getAttrValue(
      "SELECT COUNT(*) AS ATTR FROM Sprecher"
    );
    numParties = await this.getAttrValue(
      "SELECT COUNT(DISTINCT Fraktion) AS ATTR from Sprecher"
    );
    minDate = await this.getAttrValue("SELECT MIN(Datum) AS ATTR FROM Sitzung");
    maxDate = await this.getAttrValue("SELECT MAX(Datum) AS ATTR FROM Sitzung");

    return {
      numSpeeches: numSpeeches,
      numSpeakers: numSpeakers,
      numParties: numParties - 1, // -1, da fraktionslos nicht als Partei gewertet wird
      minDate: minDate,
      maxDate: maxDate,
    };
  }

  //Hilfsfunktion zum Leeren von Tabellen; wurde zum Testen der Kommentar-Funktion benötigt
  async emptyTable(tableName) {
    let query = "DELETE FROM " + tableName;
    await this.db.runQuery(query);
  }

  //Funktion, um die einzigartigen Werte aus den Tabellen zu holen für die Dropdown-Menüs
  //prettier-ignore
  async getDistinctValues() {
    let distinctTopics, distinctSpeakers, distinctParties, distinctSessions, distinctDates, distinctTOP;

    //prettier-ignore
    distinctTopics = await this.getResultSet('SELECT DISTINCT Titel FROM Agenda WHERE Titel != ""');
    distinctSpeakers = await this.getResultSet('SELECT DISTINCT AkadGrad, Vorname, Nachname FROM Sprecher WHERE Vorname != ""');
    distinctParties = await this.getResultSet('SELECT DISTINCT Fraktion FROM Sprecher WHERE Fraktion != ""');
    distinctSessions = await this.getResultSet('SELECT DISTINCT Sitzungs_Nr FROM Sitzung WHERE Sitzungs_Nr != ""');
    distinctDates = await this.getResultSet('SELECT DISTINCT Datum FROM Sitzung WHERE Datum != ""');
    distinctTOP = await this.getResultSet('SELECT DISTINCT TOP FROM Agenda WHERE TOP != ""');

    return {
      distinctTopics: distinctTopics,
      distinctSpeakers: distinctSpeakers,
      distinctParties: distinctParties,
      distinctSessions: distinctSessions,
      distinctDates: distinctDates,
      distinctTOP: distinctTOP,
    };
  }

  //Funktion, um alle Tabellen wieder zusammenzuführen, um daraus die Beitragskarten zu erstellen für die Suchmaske
  async joinAllTables() {
    //prettier-ignore
    let joinedTables = await this.getResultSet(`
    SELECT Beitrags_ID, Datum, Agenda.Sitzungs_Nr, TOP, Titel, Vorname, Nachname, AkadGrad, Fraktion, Bildunterschrift
    FROM Redebeitrag
    JOIN Sprecher ON Sprecher.Sprecher_ID = Redebeitrag.Sprecher_ID
    JOIN Agenda ON Agenda.Agenda_ID = Redebeitrag.Agenda_ID
    JOIN Sitzung ON Sitzung.Sitzungs_Nr = Agenda.Sitzungs_Nr
    ORDER BY Beitrags_ID
    `);

    return joinedTables;
  }
}

const myDatabase = new DatabaseConnector();

//prettier-ignore
export default myDatabase;
