import myDatabase from "./databaseConnector.js";

/*Übertragen der Daten aus dem Localstorage in das Seiten-Template:
 *1. Daten aus dem Localstorage holen:*/

let text = localStorage.getItem("beitrag"); //Laden aus dem Localstorage
let beitrag = JSON.parse(text); //Umwandlung in ein JSON-Format, um leichter auf die Daten zuzugreifen

/*2. Befüllen der HTML-Elemente mit den Beitragsdaten, die soeben aus dem Localstorage gezogen wurden*/
/*2.1 Info-Sektion 1:*/
document.getElementById("name").textContent =
  beitrag.speaker + " (" + beitrag.party + ")";
document.getElementById("date").textContent = beitrag.date;
document.getElementById("topic").textContent = beitrag.topic;
document.getElementById("top").textContent =
  "Tagesordnungspunkt: " + beitrag.top;
document.getElementById("session").textContent = "Sitzung: " + beitrag.session;
document.getElementById("description").textContent = beitrag.imgTxt;
document.getElementById("speakerIMG").src =
  "./data/media/" + beitrag.id + ".png";

/*2.2. Audio-Sektion 2:*/
let audioPfad = "./data/media/" + beitrag.id + ".mp3";
document.getElementById("audio").src = audioPfad;

/*2.3 Kommentar-Sektion 3:
 *2.3.1 Auslesen der Kommentare aus der Datenbank:*/
const comments = await myDatabase.getResultSet(
  "SELECT * FROM Kommentare WHERE Beitrags_ID = " +
    '"' +
    beitrag.id +
    '"' +
    " ORDER BY Timestamp ASC"
);

/*2.3.2 Befüllen der Kommentar-Box mit den Kommentaren aus der Datenbank:*/
const commentBox = document.getElementById("comments");

/*Komma-separierte Kommentare in der Datenbank wieder in einzelne Kommentare zerlegen*/
for (var i = 0; i < comments.length; i++) {
  let tags = [];

  let tag1 = comments[i].Tags.split(",")[0];
  let tag2 = comments[i].Tags.split(",")[1];
  let tag3 = comments[i].Tags.split(",")[2];
  let tag4 = comments[i].Tags.split(",")[3];
  let tag5 = comments[i].Tags.split(",")[4];

  /*Tags in ein Array schreiben*/
  tags.push(tag1, tag2, tag3, tag4, tag5);

  /*Kommentar-Box mit den einzelnen Kommentaren befüllen*/
  let commentElement = document.querySelector(".comment").cloneNode(true);
  commentElement.children[0].textContent = comments[i].Timestamp;
  commentElement.children[1].textContent = comments[i].Kommentar;
  commentElement.children[2].textContent = tags.join(" "); //Tags werden mit einem Leerzeichen getrennt

  commentBox.appendChild(commentElement);
}

export { beitrag };
